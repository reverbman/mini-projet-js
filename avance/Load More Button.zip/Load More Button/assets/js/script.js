let content = document.getElementById('content');
let btn = document.querySelector('button');

async function fetchChara() {
    let URL_Chara = "https://swapi.dev/api/people/?page=1";
    let results = await fetch(URL_Chara);;
    let data = await results.json();
    let next = data.next;
    btn.addEventListener('click', function create() {
        URL_Chara.replace("", next)
        console.log(URL_Chara);
        data.results.forEach(element => {
            let p = document.createElement('p');
            content.appendChild(p);
            p.textContent = element.name;

        });

    })


}
fetchChara();